-- Mariella Lissette Vento Pinto

-- multiple choice
-- ejercicio 2 : SacarPrimerParCOnsecutivoQueSumaN
-- ejercicio 3 : res 1 = [-1, 4, -2]
-- ejercicio 8 : el test suite no está bien diseñado





-- ejercicio 1

ejercicio1:: [Integer] -> Integer -> [Integer]
ejercicio1 (x:xs) n = sumaN (x:xs) n


sumaN:: [Integer] -> Integer -> [Integer]
sumaN [] _ = []
sumaN [x] n = [x]
sumaN (x:y:ys) n | (x + y) == n  = ys
                 | otherwise = [x] ++ sumaN (y:ys) n





-- ejercicio 4

longitud:: [Integer] -> Integer
longitud [] = 0
longitud (x:xs) = 1 + longitud xs

esDivisor:: Integer -> Integer -> Bool
esDivisor n 0 = False
esDivisor n i | mod n i == 0 = True
              | otherwise = False

divide:: Integer -> Integer -> [Integer]
divide n 1 = [1]
divide n i | esDivisor n i == True = divide n (i-1) ++ [i]
           | otherwise = divide n (i-1)

esRefactorizable:: Integer -> Bool
esRefactorizable n | esDivisor n dN == True = True
                   | otherwise = False
                   where dN = longitud (divide n n)

cantidadDeRefactorizables:: Integer -> Integer -> Integer
cantidadDeRefactorizables n m | (n<= m) && (esRefactorizable m == True) = 1 + cantidadDeRefactorizables n (m-1)
                              | (n<= m) && (esRefactorizable m == False) = cantidadDeRefactorizables n (m-1)
                              | otherwise = 0





-- ejercicio 5

quitarTodos:: (Eq t) => t -> [t] -> [t]
quitarTodos e [] = []
quitarTodos e (x:xs) | e == x = quitarTodos e xs
                     | otherwise = [x] ++ quitarTodos e xs

eliminarRepetidos:: (Eq t) => [t] -> [t]
eliminarRepetidos [] = []
eliminarRepetidos (x:xs) = [x] ++ eliminarRepetidos (quitarTodos x xs)

sociosConComprasAltas:: [(String, Integer, Bool)] -> Integer -> [String]
sociosConComprasAltas [] n = []
sociosConComprasAltas xs n = sociosListaLimpia (sonSocios (eliminarRepetidos xs)) n


sociosListaLimpia:: [(String, Integer, Bool)] -> Integer -> [String]
sociosListaLimpia [] _= []
sociosListaLimpia ((nom, compra, socio):xs) n | compra > n = [nom] ++ sociosListaLimpia xs n
                                              | otherwise = sociosListaLimpia xs n


sonSocios:: [(String, Integer, Bool)] -> [(String, Integer, Bool)]
sonSocios [] = []
sonSocios ((nom, com, socio):xs) | socio == True = [(nom,com, socio)] ++ sonSocios xs
                                 | otherwise = sonSocios xs


-- ejercicio 6

indice:: (Eq t) => [t] -> Integer -> [t]
indice [] _ = []
indice [x] 0 = [x]
indice (x:xs) n | n == 0 = [x]
                | otherwise = indice xs (n-1)

indice2:: (Eq t) => [t] -> t -> Integer
indice2 (x:xs) m | x == m = 0
                 | otherwise = 1 + indice2 xs m

reemplazarMatriz:: [[Integer]] -> Integer -> [[Integer]]
reemplazarMatriz [] _ = []
reemplazarMatriz (x:xs) n | (indice x n) /= [0] = (reemplazarFila x n): (reemplazarMatriz xs (n+1))
                          | otherwise = x: (reemplazarMatriz xs (n+1))


reemplazarFila:: [Integer] -> Integer -> [Integer]
reemplazarFila [] _ = []
reemplazarFila (x:xs) n | n == (indice2 (x:xs) x ) = [0] ++ xs 
                        | otherwise = [x] ++ (reemplazarFila xs (n-1))

ejercicio6:: [[Integer]] -> [[Integer]]
ejercicio6 [] = []
ejercicio6 xs = reemplazarMatriz xs 0




